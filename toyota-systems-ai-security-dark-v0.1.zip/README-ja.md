# AIエージェントのセキュリティとKongの対応範囲 v0.1

toyota-systems-ai-security-dark-v0.1.html を通常のデスクトップブラウザで開いてください。単一HTMLにCSS・JavaScript・SVG・reveal.jsを梱包しています。Google Fontsと出典リンクにはネット接続を使います。

下キー・下部の↓で進み、上キー・↑で戻ります。左上「セクション」から章へ移動できます。KONGは表紙へ。図の選択肢はクリックで切り替わります。テーマはdark固定です。実際の製品APIへは接続しません。

公開されたURLを共有する場合も、このHTMLと同じ版を渡してください。SHA256SUMS.txtで照合できます。直接ファイル起動・全画面・受取環境の確認結果は制作側の記録で区別します。

reveal.js 6.0.2のMITライセンスをLICENSE-reveal.txtおよびHTML内に保持しています。各商標・コンテンツの権利は各権利者に帰属します。
